### BEGIN INIT INFO
# Provides:          initrd-tools
# Required-Start:    mountdevsubfs
# Required-Stop: 
# Default-Start:     S
# Default-Stop:
### END INIT INFO
